# 🚀 Quick Reference Card

Essential URLs and commands for your Terminal Themes repository.

---

## 🔗 Repository URLs

**Main Repository:**
```
https://github.com/RLR-GitHub/terminal-themes
```

**Clone URL:**
```bash
git clone https://github.com/RLR-GitHub/terminal-themes.git
```

**GitHub Pages Demo:**
```
https://RLR-GitHub.github.io/terminal-themes
```

---

## 📦 Installation Commands

**One-Line Install:**
```bash
curl -fsSL https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/install.sh | bash
```

**Uninstall:**
```bash
curl -fsSL https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/install.sh | bash -s -- --uninstall
```

---

## 🎨 Individual Theme Downloads

**Halloween:**
```bash
curl -o ~/matrix.sh https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-halloween.sh && chmod +x ~/matrix.sh
```

**Christmas:**
```bash
curl -o ~/matrix.sh https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-christmas.sh && chmod +x ~/matrix.sh
```

**Easter:**
```bash
curl -o ~/matrix.sh https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-easter.sh && chmod +x ~/matrix.sh
```

**Hacker:**
```bash
curl -o ~/matrix.sh https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-hacker.sh && chmod +x ~/matrix.sh
```

**Matrix:**
```bash
curl -o ~/matrix.sh https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-classic.sh && chmod +x ~/matrix.sh
```

---

## 🛠️ Setup Commands

**Initialize Repository:**
```bash
mkdir terminal-themes && cd terminal-themes
git init
git branch -M main
```

**Add Remote:**
```bash
git remote add origin https://github.com/RLR-GitHub/terminal-themes.git
```

**First Commit:**
```bash
git add .
git commit -m "Initial commit: Terminal themes collection v3.0"
git push -u origin main
```

**Create Release:**
```bash
git tag -a v3.0.0 -m "Release v3.0.0 - Initial theme collection"
git push origin v3.0.0
```

---

## 🌐 Raw File URLs

**Install Script:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/install.sh
```

**Halloween Theme:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-halloween.sh
```

**Christmas Theme:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-christmas.sh
```

**Easter Theme:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-easter.sh
```

**Hacker Theme:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-hacker.sh
```

**Matrix Theme:**
```
https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/themes/matrix-classic.sh
```

---

## 📊 Badges (for README)

```markdown
![GitHub stars](https://img.shields.io/github/stars/RLR-GitHub/terminal-themes?style=social)
![GitHub forks](https://img.shields.io/github/forks/RLR-GitHub/terminal-themes?style=social)
![GitHub watchers](https://img.shields.io/github/watchers/RLR-GitHub/terminal-themes?style=social)
![GitHub issues](https://img.shields.io/github/issues/RLR-GitHub/terminal-themes)
![GitHub license](https://img.shields.io/github/license/RLR-GitHub/terminal-themes)
```

---

## 🔍 GitHub Interface URLs

**Issues:**
```
https://github.com/RLR-GitHub/terminal-themes/issues
```

**New Issue:**
```
https://github.com/RLR-GitHub/terminal-themes/issues/new
```

**Pull Requests:**
```
https://github.com/RLR-GitHub/terminal-themes/pulls
```

**Releases:**
```
https://github.com/RLR-GitHub/terminal-themes/releases
```

**Wiki:**
```
https://github.com/RLR-GitHub/terminal-themes/wiki
```

**Discussions:**
```
https://github.com/RLR-GitHub/terminal-themes/discussions
```

**Contributors:**
```
https://github.com/RLR-GitHub/terminal-themes/graphs/contributors
```

**Settings:**
```
https://github.com/RLR-GitHub/terminal-themes/settings
```

---

## 📱 Social Media Posts

**Twitter/X:**
```
Just launched Terminal Themes! 🚀 5 Matrix-style themes to transform your terminal into a cyberpunk experience.

✨ Pure Bash, no dependencies
🎨 Halloween, Christmas, Easter, Hacker, Matrix
⚡ One-line install

Check it out: https://github.com/RLR-GitHub/terminal-themes

#bash #terminal #cyberpunk #opensource
```

**Reddit (r/commandline):**
```
Title: [OC] Terminal Themes - Transform your terminal with Matrix-style animations

I created a collection of 5 Matrix-style terminal themes (Halloween, Christmas, Easter, Hacker, and classic Matrix) that run entirely in bash with no dependencies.

Features:
• Pure bash implementation
• 256-color support
• Multiple themed animations
• One-line installer
• Custom prompts and aliases

Demo: https://RLR-GitHub.github.io/terminal-themes
Repo: https://github.com/RLR-GitHub/terminal-themes

Installation:
curl -fsSL https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main/install.sh | bash

Would love feedback and contributions!
```

**LinkedIn:**
```
Excited to share my latest open-source project: Terminal Themes! 

As part of my MSECE program at Purdue, I've been exploring systems programming and terminal customization. This project combines my interests in computer engineering with creative coding.

🎨 5 unique Matrix-style themes
⚡ Automated installation system  
📚 Comprehensive documentation
🔧 Pure Bash - no dependencies

The project demonstrates:
• Systems programming & terminal I/O
• Bash scripting & ANSI escape codes
• Software distribution & deployment
• Open source community management

Check it out: https://github.com/RLR-GitHub/terminal-themes

#OpenSource #SoftwareEngineering #Bash #ComputerEngineering #Purdue
```

---

## 📧 Contact Information

**Author:** Roderick Lawrence Renwick (Rory)
**GitHub:** @RLR-GitHub
**Email:** rodericklrenwick@gmail.com
**Website:** https://r0ry.com | https://rlr.dev
**Education:** MSECE @ Purdue University

---

## 📂 Repository Structure

```
terminal-themes/
├── README.md                    # Main docs
├── QUICKSTART.md                # Fast setup
├── LICENSE                      # MIT License
├── CONTRIBUTING.md              # Contributor guide
├── CHANGELOG.md                 # Version history
├── install.sh                   # Auto installer
├── themes/
│   ├── matrix-halloween.sh
│   ├── matrix-christmas.sh
│   ├── matrix-easter.sh
│   ├── matrix-hacker.sh
│   └── matrix-classic.sh
└── demo/
    └── rory-terminal-themes.html
```

---

**Version:** 3.0.0  
**License:** MIT  
**Status:** Ready for deployment ✅

---

Print this reference card for quick access to all your URLs and commands!
