#!/bin/bash

# ================================
# Rory's Terminal Theme Installer
# ================================
# Automated installation script for terminal themes
# Usage: curl -fsSL https://raw.githubusercontent.com/yourusername/terminal-themes/main/install.sh | bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Detect shell
detect_shell() {
    if [ -n "$ZSH_VERSION" ]; then
        echo "zsh"
    elif [ -n "$BASH_VERSION" ]; then
        echo "bash"
    else
        echo "unknown"
    fi
}

SHELL_TYPE=$(detect_shell)

# Print banner
print_banner() {
    clear
    echo -e "${CYAN}"
    echo "  ╔═══════════════════════════════════════════╗"
    echo "  ║                                           ║"
    echo "  ║    Rory's Terminal Theme Collection       ║"
    echo "  ║         Installation Wizard               ║"
    echo "  ║                                           ║"
    echo "  ╚═══════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Print step
print_step() {
    echo -e "${BLUE}==>${NC} $1"
}

# Print success
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

# Print error
print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Print warning
print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Check requirements
check_requirements() {
    print_step "Checking requirements..."
    
    # Check bash version
    if [ -n "$BASH_VERSION" ]; then
        BASH_MAJOR=$(echo "$BASH_VERSION" | cut -d. -f1)
        if [ "$BASH_MAJOR" -lt 4 ]; then
            print_error "Bash 4.0+ required. Current version: $BASH_VERSION"
            exit 1
        fi
        print_success "Bash version OK ($BASH_VERSION)"
    else
        print_warning "Not running in Bash, skipping version check"
    fi
    
    # Check for curl
    if ! command -v curl &> /dev/null; then
        print_error "curl is required but not installed"
        exit 1
    fi
    print_success "curl found"
    
    # Check terminal color support
    if [ -z "$TERM" ]; then
        print_warning "TERM variable not set, colors may not work"
    else
        print_success "Terminal type: $TERM"
    fi
}

# Theme selection menu
select_theme() {
    echo ""
    print_step "Select a theme:"
    echo ""
    echo -e "  ${YELLOW}1)${NC} 🎃 Halloween    - Spooky orange/black"
    echo -e "  ${YELLOW}2)${NC} 🎄 Christmas   - Festive red/green"
    echo -e "  ${YELLOW}3)${NC} 🐰 Easter      - Pastel rainbow"
    echo -e "  ${YELLOW}4)${NC} 💻 Hacker      - Bright green cyber"
    echo -e "  ${YELLOW}5)${NC} 🟢 Matrix      - Classic green"
    echo ""
    read -p "Enter choice [1-5]: " choice
    
    case $choice in
        1) THEME="halloween"; THEME_NAME="Halloween" ;;
        2) THEME="christmas"; THEME_NAME="Christmas" ;;
        3) THEME="easter"; THEME_NAME="Easter" ;;
        4) THEME="hacker"; THEME_NAME="Hacker" ;;
        5) THEME="classic"; THEME_NAME="Matrix" ;;
        *) print_error "Invalid choice"; exit 1 ;;
    esac
    
    print_success "Selected: $THEME_NAME theme"
}

# Download theme script
download_theme() {
    print_step "Downloading $THEME_NAME theme..."
    
    REPO_URL="https://raw.githubusercontent.com/RLR-GitHub/terminal-themes/main"
    SCRIPT_URL="$REPO_URL/themes/matrix-${THEME}.sh"
    
    if curl -fsSL "$SCRIPT_URL" -o ~/matrix.sh; then
        chmod +x ~/matrix.sh
        print_success "Theme script installed to ~/matrix.sh"
    else
        print_error "Failed to download theme script"
        exit 1
    fi
}

# Backup existing configuration
backup_config() {
    if [ "$SHELL_TYPE" = "bash" ]; then
        CONFIG_FILE="$HOME/.bashrc"
    elif [ "$SHELL_TYPE" = "zsh" ]; then
        CONFIG_FILE="$HOME/.zshrc"
    else
        print_error "Unsupported shell: $SHELL_TYPE"
        exit 1
    fi
    
    if [ -f "$CONFIG_FILE" ]; then
        print_step "Backing up $CONFIG_FILE..."
        cp "$CONFIG_FILE" "${CONFIG_FILE}.backup.$(date +%Y%m%d_%H%M%S)"
        print_success "Backup created"
    fi
}

# Configure shell
configure_shell() {
    print_step "Configuring shell..."
    
    # Check if already configured
    if grep -q "# Rory's Cyberpunk Terminal Setup" "$CONFIG_FILE" 2>/dev/null; then
        print_warning "Configuration already exists in $CONFIG_FILE"
        read -p "Overwrite existing configuration? [y/N]: " overwrite
        if [[ ! "$overwrite" =~ ^[Yy]$ ]]; then
            print_warning "Skipping shell configuration"
            return
        fi
    fi
    
    # Add configuration
    cat >> "$CONFIG_FILE" << 'EOF'

# ================================
# Rory's Cyberpunk Terminal Setup
# ================================

# Set terminal title
function set-title() {
    echo -ne "\033]0;$@\007"
}

# System status command
function sys-status() {
    echo -e "\e[1;32m╓───[ SYSTEM STATUS ]──────────────\e[0m"
    echo -e "\e[1;32m╟─\e[0m \e[1;33mUser:\e[0m $(whoami)@$(hostname)"
    echo -e "\e[1;32m╟─\e[0m \e[1;33mUptime:\e[0m $(uptime -p 2>/dev/null || uptime)"
    echo -e "\e[1;32m╟─\e[0m \e[1;33mDisk:\e[0m $(df -h / | awk 'NR==2{print $5}')"
    echo -e "\e[1;32m╙──────────────────────────────────\e[0m"
}

set-title "r0ry.computer"

# Hacker-themed aliases
alias ll='ls -la --color=auto 2>/dev/null || ls -la'
alias gitc='git commit -m'
alias hack='echo "Initiating hack sequence..." && sleep 1 && echo "Access granted."'
alias scan='echo "Scanning network..." && ping -c 3 8.8.8.8'
alias matrix='~/matrix.sh'

# Custom cyberpunk prompt
PS1='\[\e[0;32m\]┌──(\[\e[1;31m\]\u@\h\[\e[0;32m\])─[\[\e[0m\]\w\[\e[0;32m\]]\n└──\$ \[\e[0m\]'

# Launch Matrix animation on startup
if [ -f ~/matrix.sh ]; then
    ~/matrix.sh --init
fi
EOF
    
    print_success "Shell configuration added to $CONFIG_FILE"
}

# Test installation
test_installation() {
    print_step "Testing installation..."
    
    if [ -f ~/matrix.sh ] && [ -x ~/matrix.sh ]; then
        print_success "Matrix script is executable"
    else
        print_error "Matrix script not found or not executable"
        exit 1
    fi
    
    echo ""
    read -p "Run a quick test? [Y/n]: " test_run
    if [[ ! "$test_run" =~ ^[Nn]$ ]]; then
        print_step "Running 5-second test animation..."
        ~/matrix.sh --init
    fi
}

# Print completion message
print_completion() {
    echo ""
    echo -e "${GREEN}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                                           ║${NC}"
    echo -e "${GREEN}║     Installation Complete! 🎉            ║${NC}"
    echo -e "${GREEN}║                                           ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}Next steps:${NC}"
    echo ""
    echo -e "  1. Reload your shell:"
    echo -e "     ${YELLOW}source $CONFIG_FILE${NC}"
    echo ""
    echo -e "  2. Or start a new terminal session"
    echo ""
    echo -e "${CYAN}Available commands:${NC}"
    echo ""
    echo -e "  ${YELLOW}matrix${NC}      - Run Matrix animation"
    echo -e "  ${YELLOW}sys-status${NC}  - Display system info"
    echo -e "  ${YELLOW}hack${NC}        - Hacker simulation"
    echo -e "  ${YELLOW}scan${NC}        - Network scan simulation"
    echo -e "  ${YELLOW}ll${NC}          - Enhanced file listing"
    echo ""
    echo -e "${CYAN}Customization:${NC}"
    echo -e "  Edit ${YELLOW}~/matrix.sh${NC} to customize your theme"
    echo ""
    echo -e "${CYAN}Documentation:${NC}"
    echo -e "  https://github.com/yourusername/terminal-themes"
    echo ""
    echo -e "${GREEN}Enjoy your cyberpunk terminal! 🚀${NC}"
    echo ""
}

# Uninstall function
uninstall() {
    print_banner
    print_warning "This will remove the terminal theme configuration"
    read -p "Are you sure? [y/N]: " confirm
    
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        echo "Uninstall cancelled"
        exit 0
    fi
    
    print_step "Removing matrix script..."
    rm -f ~/matrix.sh
    print_success "Matrix script removed"
    
    print_step "Removing configuration from shell..."
    if [ "$SHELL_TYPE" = "bash" ]; then
        CONFIG_FILE="$HOME/.bashrc"
    elif [ "$SHELL_TYPE" = "zsh" ]; then
        CONFIG_FILE="$HOME/.zshrc"
    fi
    
    # Remove configuration block
    if [ -f "$CONFIG_FILE" ]; then
        sed -i.bak '/# Rory.*s Cyberpunk Terminal Setup/,/^$/d' "$CONFIG_FILE" 2>/dev/null || \
        sed -i '' '/# Rory.*s Cyberpunk Terminal Setup/,/^$/d' "$CONFIG_FILE" 2>/dev/null
        print_success "Configuration removed"
    fi
    
    echo ""
    print_success "Uninstall complete. Restart your terminal for changes to take effect."
}

# Main installation flow
main() {
    # Check for uninstall flag
    if [ "$1" = "--uninstall" ] || [ "$1" = "-u" ]; then
        uninstall
        exit 0
    fi
    
    print_banner
    check_requirements
    select_theme
    backup_config
    download_theme
    configure_shell
    test_installation
    print_completion
}

# Run main function
main "$@"
